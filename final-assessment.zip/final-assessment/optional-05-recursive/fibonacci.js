/**
 * Fungsi untuk menghasilkan deret Fibonacci hingga elemen ke-n.
 * @param {number} n - Indeks elemen Fibonacci.
 * @returns {number[]} - Deret Fibonacci hingga elemen ke-n.
 */
function fibonacci(n) {
    if (n === 0) {
      return [0]; 
    }
    if (n === 1) {
      return [0, 1];1
    }
    
    const series = fibonacci(n - 1); 
    series.push(series[series.length - 1] + series[series.length - 2]); // Tambahkan elemen Fibonacci berikutnya
    return series;
  }
  
  // Jangan hapus kode di bawah ini!
  export default fibonacci;  