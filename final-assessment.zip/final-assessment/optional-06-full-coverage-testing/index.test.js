import { test } from 'node:test';
import assert from 'node:assert';
import sum from './index.js';

test('should return the sum of two positive numbers', () => {
  const result = sum(2, 3);
  assert.strictEqual(result, 5);
});

test('should return the sum of zero and a positive number', () => {
  const result = sum(0, 5);
  assert.strictEqual(result, 5);
});

test('should return the sum of a positive number and zero', () => {
  const result = sum(5, 0);
  assert.strictEqual(result, 5);
});

test('should return 0 when one input is negative', () => {
  const result = sum(-1, 5);
  assert.strictEqual(result, 0);
});

test('should return 0 when both inputs are negative', () => {
  const result = sum(-1, -1);
  assert.strictEqual(result, 0);
});

test('should return 0 when one input is not a number', () => {
  const result = sum('a', 5);
  assert.strictEqual(result, 0);
});

test('should return 0 when both inputs are not numbers', () => {
  const result = sum('a', 'b');
  assert.strictEqual(result, 0);
});

test('should return 0 when both inputs are undefined', () => {
  const result = sum(undefined, undefined);
  assert.strictEqual(result, 0);
});

test('should return 0 when both inputs are null', () => {
  const result = sum(null, null);
  assert.strictEqual(result, 0);
});
